#include "timsline.h"
using namespace std;

TimsLine::TimsLine(string name){ 
	this->name = name;
	this->isOwnable = false; 
}

void TimsLine::specialty(Player *p){
  
}
