#ifndef PROPERTY_H
#define PROPERTY_H
//using namespace std;
#include <iostream>

class Property{ 
	public:

	std::string name; 
	bool isOwnable;  
};

#endif
